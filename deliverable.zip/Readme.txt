Data model named WorkEffort was modelled by PowerDesigner 16.6.

1) WorkEffort Directory:
    Project files of PowerDesigner including CDM(Conceptual Data Model) and PDM(Physical Data Model).

2) work_effort.jpg
    Image of model.

3) work_effort.sql
    Exported DB script for MySQL 5.0 (Applicable to MySQL 8)

4) References:
- 《节选--企业业务核心系统之核心数据模型--设计文档---2021.10.19》
- 《数据模型资源手册 I》: Chapter 6 工作计划模型
- 《数据模型资源手册 III》: Chapter 2 设置角色
- 《分析模式-可复用的对象模型》"": 2.1 2.2. 2.3 团体和组织结构
- 《模型驱动软件开发：技术、工程与管理》 : 6.1 元模型定义


